<?php
	 include_once("header.php");
	 include_once("sidebar.php");
?>
<html>
	<head>
	<center><title>supermarket_cupcup.com</title></center>
	</head>
	<body>
	<center><h2>supermarket_cupcup.com</h2></center>
	<br/>
	<center><a href="inputbarang.php">+ TAMBAH BARANG</a></center>
	<br/>
	<center><table border="1"></center>
	<tr>
		<th>No</th>
		<th>Id_Barang</th>
		<th>Nama</th>
		<th>kategor_Id</th>
		<th>Satuan_Id</th>
		<th>OPSI</th>
	</tr>
	<?php
	include 'koneksi.php';
	$no =1;
	$data = mysqli_query($koneksi,"select * from barang");
	while($d= mysqli_fetch_array($data)){
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $d['id_barang']; ?></td>
			<td><?php echo $d['nama_barang']; ?></td>
			<td><?php echo $d['kategori_id']; ?></td>
			<td><?php echo $d['satuan_id']; ?></td>
			<td>
				<a href="edit_barang.php?id=<?php echo $d['id_barang']; ?>">EDIT</a>
				<a href="hapus_barang.php?id=<?php echo $d['id_barang']; ?>">HAPUS</a>
			<td>
		</tr>
	<?php
	}
	?>
	</table>
	</body>
	</html>
	<?php
	include_once("footer.php");
?>