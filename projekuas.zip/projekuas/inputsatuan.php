<?php
include "koneksi.php";
	 
	if(!empty($_POST['save']))
	{
		$nama = $_POST['nama'];
		$a=mysqli_query($koneksi,"insert into satuan values('','$nama')");
		if ($a)
		{
		//header("location:tampilsatuan.php");
		}
		else
		{
			echo mysqli_error($koneksi);
		}
	}
?>
<center><h2>supermarket_cupcup.com<h/2></center>
<br/> 
<center><a href="tampilsatuan.php">KEMBALI<a/></center>
<br/>
<br/>
<center><h3>TAMBAH DATA SATUAN</h3></center>
<form method="POST">
	<center><table></center>
    <tr>
	<td>Nama</td>
	<td><input type="text" name="nama"></td>
	</tr>
	<td></td>
	<td>
		<input type="submit" name="save">
	</td>
	</tr>
	</table>
	</form>
