
<! DOCTYPE html>
<html>
<html>
<center><title>supermarket_cupcup.com</title></center>
<link rel="stylesheet" type="text/css" href="bg.css">
</head>
<?php
//koneksi database
include "koneksi.php";
if(!empty($_POST['save'])){
$nama_barang = $_POST['nama_barang'];
$kategori_id = $_POST['kategori_id'];
$satuan_id = $_POST['satuan_id'];
$a=mysqli_query($koneksi,"insert into barang values('','$nama_barang','$kategori_id','$satuan_id')");
if ($a){
//header("location:tampilbarang.php");
}else{
	echo mysqli_error($koneksi);
}
}
?>
<body>
<center><h2>supermarket_cupcup.com<h/2></center>
<br/>
<center><a href="tampilbarang.php">KEMBALI<a/></center>
<br/>
<br/>
<center><h3>TAMBAH DATA BARANG</h3></center>
<form method="POST">
	<center><table></center>
	<tr>
	<td>Nama_Barang</td>
	<td><input type="text" name="nama_barang"></td>
	</tr>
	<tr>
	<td>Kategori_Id</td>
	<td><input type="text" name="kategori_id"></td>
	</tr>
	<tr>
	<td>Status</td>
	<td><select name="satuan_id">
	<option value="">-----Pilih</option>
	<option value="3">3</option>
	<option value="2">2</option>
	<option value="1">1</option>
	</select>
	<td>
	</tr>
	<tr>
	<td></td>
	<td><input type="submit" name="save"><td>
	</tr>
	</table>
	</form>
	</body>
	</html>
