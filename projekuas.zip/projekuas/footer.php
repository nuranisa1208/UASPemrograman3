     <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer text-center">
                © 2021 Monster Admin by <a href="https://www.wrappixel.com/">wrappixel.com</a>
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="monster-admin-lite-master/assets/plugins/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="monster-admin-lite-master/assets/plugins/bootstrap/dist/monster-admin-lite-master/monster-html/js/bootstrap.bundle.min.js"></script>
    <script src="monster-admin-lite-master/monster-html/js/app-style-switcher.js"></script>
    <!--Wave Effects -->
    <script src="monster-admin-lite-master/monster-html/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="monster-admin-lite-master/monster-html/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="monster-admin-lite-master/monster-html/js/custom.js"></script>
    <!--This page JavaScript -->
    <!--flot chart-->
    <script src="monster-admin-lite-master/assets/plugins/flot/jquery.flot.js"></script>
    <script src="monster-admin-lite-master/assets/plugins/flot.tooltip/monster-admin-lite-master/monster-html/js/jquery.flot.tooltip.min.js"></script>
    <script src="monster-admin-lite-master/monster-html/js/pages/dashboards/dashboard1.js"></script>
</body>

</html>