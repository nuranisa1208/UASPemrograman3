<?php
	 include_once("header.php");
	 include_once("sidebar.php");
?>
</html>
	<head>
	<center><title>supermarket_cupcup.com</title></center>
	</head>
	<body>
	<center><h2>supermarket_cupcup.com</h2></center>
	<br/>
	<center><a href="inputkategori.php">KATEGORI+ TAMBAH KATEGORI</a></center>
	<br/>
	<center><table border="1"></center>
	<tr>
		<th>No</th>
		<th>Id_Kategori</th>
		<th>Nama</th>
		<th>OPSI</th>
	</tr>
	<?php
	include 'koneksi.php';
	$no =1;
	$data = mysqli_query($koneksi,"select * from kategori");
	while($d= mysqli_fetch_array($data)){
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $d['id_kategori']; ?></td>
			<td><?php echo $d['nama']; ?></td>
			<td>
				<a href="edit_member.php?id=<?php echo $d['id_kategori']; ?>">EDIT</a>
				<a href="hapus_member.php?id=<?php echo $d['id_kategori']; ?>">HAPUS</a>
			<td>
		</tr>
	<?php
	}
	?>
	</table>
	</body>
	</html>
	<?php
	include_once("footer.php");
?>