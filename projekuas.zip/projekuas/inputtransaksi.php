
<! DOCTYPE html>
<html>
<html>
<center><title>supermarket_cupcup.com></title></center>
<link rel="stylesheet" type="text/css" href="bg.css">
</head>
<?php
//koneksi database
include "koneksi.php";
if(!empty($_POST['save'])){
$nama_transaksi = $_POST['nama_transaksi'];
$tgl_transaksi = $_POST['tgl_transaksi'];
$harga = $_POST['harga'];
$qty = $_POST['qty'];
$id_barang = $_POST['barang_id'];
$diskon = $_POST['diskon'];
$id_pelanggan = $_POST['id_pelanggan'];

$a=mysqli_query($koneksi,"insert into transaksi values('','$nama_transaksi','$tgl_transaksi','$harga','$qty','$id_barang','$diskon','$id_pelanggan')");
if ($a)
{
//header("location:tampiltransaksi.php");
}
else
{
	echo mysqli_error($koneksi);
	
}
}
$querybarang = "SELECT * FROM barang";
$resultbarang = mysqli_query($koneksi,$querybarang);

$querypelanggan = "SELECT * FROM pelanggan";
$resultpelanggan = mysqli_query($koneksi,$querypelanggan);

?>
<body>
<center><h2>supermarket_cupcup.com<h/2></center>
<br/>
<center><a href="tampiltransaksi.php">KEMBALI<a/></center>
<br/>
<br/>
<center><h3>TAMBAH DATA TRANSAKSI</h3></center>
<form method="POST">
<center><table></center>
	<tr>
	<td>Nama_Transaksi</td>
	<td><input type="text" Name="nama_transaksi"></td>
	</tr>
	<tr>
	<td>Tgl_transaksi</td>
	<td><input type="date" Name="tgl_transaksi"></td>
	</tr>
	<tr>
	<td>Harga</td>
	<td><input type="text" Name="harga"></td>
	</tr>
	<tr>
	<td>Qty</td>
	<td><input type="text" Name="qty"></td>
	</tr>
	<tr>
	<td>Id_Barang</td>
	<td><select name="barang_id">
	<option value="">---Pilih---</option>
	<?php
	while ($databarang=mysqli_fetch_array($resultbarang))
	{
		echo "<option value=$databarang[id_barang]>$databarang[nama_barang]</option>";
	}
	?>
	</select>
	<td>
	<tr>
	<td>Diskon</td>
	<td><input type="text" Name="diskon"></td>
	</tr>
	<td>Id_pelanggan</td>
	<td><select name="id_pelanggan">
	<option value="">---Pilih---</option>
	<?php
	while ($datpelanggan=mysqli_fetch_array($resultpelanggan))
	{
		echo "<option value=$datpelanggan[id_pelanggan]> $datpelanggan[nama_pelanggan]</option>";
	}
	?>
	</select>
	</td>
	</tr>
	<tr>
	<td></td>
	<td><input type="submit" name="save"><td>
	</tr>
	</table>
	</form>
	</body>
	</html>
