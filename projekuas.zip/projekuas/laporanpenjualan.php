<?php
	 include_once("header.php");
	 include_once("sidebar.php");
?>
<center><h2>Report Penjualan </h2>

<table border="1">
<tr>

	<th>pelanggan</th>
	<th>status</th>
	<th>kategori </th>
	<th>barang</th>
	<th>qty</th>
	<th>harga</th>
	<th>diskon</th>
	<th>Total transaksi</th>
	</tr>
<?php
	include"koneksi.php";
	$no=1;
	$ambildata=mysqli_query($koneksi,"select p.nama_pelanggan , p.status, k.nama as nama_kategori, b.nama_barang, t.qty, t.harga, t.diskon, (t.harga-((t.diskon/100)*t.qty*t.harga)) as total  from transaksi t LEFT JOIN pelanggan p on t.id_pelanggan = p.id_pelanggan LEFT JOIN barang b on b.id_barang=t.id_barang LEFT JOIN kategori k on b.kategori_id = k.id_kategori;");
	while ($tampil = mysqli_fetch_array($ambildata)){
		?>
		<tr>
			
			<td><?php echo $tampil['nama_pelanggan']; ?></td>
			<td><?php echo $tampil['status']; ?></td>
			<td><?php echo $tampil['nama_kategori']; ?></td>
			<td><?php echo $tampil['nama_barang']; ?></td>
			<td><?php echo $tampil['qty']; ?></td>
			<td><?php echo $tampil['harga']; ?></td>
			<td><?php echo $tampil['diskon']; ?></td>
			<td><?php echo $tampil['total']; ?></td>
			<td>
			</tr>
		<?php
	}
			

?>
</table>
</center>
</body>
	</html>
	<?php
	include_once("footer.php");
?>