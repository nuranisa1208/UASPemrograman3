
<! DOCTYPE html>
<html>
<html>
<center><title>supermarket_cupcup.com</title></center>
<link rel="stylesheet" type="text/css" href="bg.css">
</head>
<?php
//koneksi database
include "koneksi.php";
if(!empty($_POST['save'])){
$nama = $_POST['nama'];
$a=mysqli_query($koneksi,"insert into kategori values('','$nama')");
if ($a){
//header("location:tampilkategori.php");
}else{
	echo mysqli_error($koneksi);
}
}
?>
<body>
<center><h2>supermarket_cupcup.com<h/2></center>
<br/>
<center><a href="tampilkategori.php">KEMBALI<a/></center>
<br/>
<br/>
<center><h3>TAMBAH DATA KATEGORI</h3></center>
<form method="POST">
	<center><table></center>
	<tr>
    <tr>
	<td>Nama</td>
	<td><input type="text" name="nama"></td>
	</tr>
	<td></td>
	<td><input type="submit" name="save"><td>
	</tr>
	</table>
	</form>
	</body>
	</html>
